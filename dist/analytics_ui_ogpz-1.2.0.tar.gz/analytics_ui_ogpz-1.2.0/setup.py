from setuptools import setup

setup(
    name="analytics_ui_ogpz",
    version="1.2.0",
    py_modules=["excel_merger"],
    install_requires=[
        'pandas',
        'openpyxl',
        'xlrd',
        'numpy',
    ],
    entry_points={
        'console_scripts': [
            'analytics-ui=excel_merger:main',
        ],
    },
    include_package_data=True,
    author="User",
    description="Tool for merging and analyzing Excel files",
)